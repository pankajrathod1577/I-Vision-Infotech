import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Image } from '@/components/ui/image';
import { Users, Target, Award, BookOpen, Heart, Lightbulb } from 'lucide-react';
import { motion } from 'framer-motion';

export default function AboutPage() {
  const values = [
    {
      icon: <Target className="h-8 w-8 text-primary-foreground" />,
      title: "Excellence",
      description: "We strive for excellence in everything we do, from curriculum design to student support."
    },
    {
      icon: <Heart className="h-8 w-8 text-primary-foreground" />,
      title: "Student-Centric",
      description: "Our students are at the heart of everything we do. We're committed to their success."
    },
    {
      icon: <Lightbulb className="h-8 w-8 text-primary-foreground" />,
      title: "Innovation",
      description: "We continuously innovate our teaching methods and curriculum to stay ahead."
    },
    {
      icon: <Users className="h-8 w-8 text-primary-foreground" />,
      title: "Community",
      description: "We foster a supportive learning community where everyone can thrive."
    }
  ];

  const stats = [
    { number: "500+", label: "Students Trained" },
    { number: "95%", label: "Placement Rate" },
    { number: "50+", label: "Partner Companies" },
    { number: "10+", label: "Years Experience" }
  ];

  const team = [
    {
      name: "Dr. Sarah Johnson",
      role: "Director & Founder",
      image: "https://static.wixstatic.com/media/04ae4d_c6fc7fe52c1d48479bb2c4bea56dc440~mv2.png?originWidth=384&originHeight=384",
      description: "PhD in Computer Science with 15+ years in industry and academia."
    },
    {
      name: "Michael Chen",
      role: "Head of Training",
      image: "https://static.wixstatic.com/media/04ae4d_5766c3c6f1f04f45b2ed721ea6db69f3~mv2.png?originWidth=384&originHeight=384",
      description: "Former Google engineer with expertise in full-stack development."
    },
    {
      name: "Priya Sharma",
      role: "Placement Coordinator",
      image: "https://static.wixstatic.com/media/04ae4d_93496773ed404876a82979ed9014253d~mv2.png?originWidth=384&originHeight=384",
      description: "HR specialist with strong industry connections and 8+ years experience."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="bg-white/95 backdrop-blur-md shadow-lg border-b border-blue-100 sticky top-0 z-50">
        <div className="max-w-[120rem] mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-blue-500 rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white font-heading font-bold text-lg">IV</span>
              </div>
              <span className="font-heading text-2xl font-bold bg-gradient-to-r from-darktext to-blue-600 bg-clip-text text-transparent">I vision Training</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <Link to="/" className="text-darktext hover:text-blue-600 transition-all duration-300 font-paragraph relative group">
                Home
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link to="/about" className="text-blue-600 font-paragraph font-semibold relative">
                About
                <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-gradient-to-r from-blue-500 to-blue-600"></span>
              </Link>
              <Link to="/courses" className="text-darktext hover:text-blue-600 transition-all duration-300 font-paragraph relative group">
                Courses
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link to="/gallery" className="text-darktext hover:text-blue-600 transition-all duration-300 font-paragraph relative group">
                Gallery
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link to="/placement" className="text-darktext hover:text-blue-600 transition-all duration-300 font-paragraph relative group">
                Placement
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link to="/contact" className="text-darktext hover:text-blue-600 transition-all duration-300 font-paragraph relative group">
                Contact
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
              </Link>
            </div>
            <Button asChild className="bg-gradient-to-r from-blue-500 to-blue-600 text-white hover:from-blue-600 hover:to-blue-700 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <Link to="/contact">Get Started</Link>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary via-primary/80 to-secondary py-20">
        <div className="max-w-[120rem] mx-auto px-6">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center space-y-6"
          >
            <h1 className="font-heading text-5xl lg:text-6xl font-bold text-darktext">
              About Our Institute
            </h1>
            <p className="font-paragraph text-xl text-darktext/80 max-w-3xl mx-auto">
              Empowering careers through quality education, industry expertise, and personalized support since 2014
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="max-w-[120rem] mx-auto px-6 py-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="space-y-6">
              <h2 className="font-heading text-4xl font-bold text-darktext">Our Mission</h2>
              <p className="font-paragraph text-lg text-darktext/80 leading-relaxed">
                To bridge the gap between academic learning and industry requirements by providing comprehensive, 
                hands-on training programs that prepare students for successful careers in technology and beyond.
              </p>
              <p className="font-paragraph text-lg text-darktext/80 leading-relaxed">
                We believe in nurturing talent, fostering innovation, and creating opportunities for individuals 
                to achieve their professional goals through quality education and industry connections.
              </p>
            </div>
            <div className="bg-contentblockbackground p-6 rounded-lg">
              <h3 className="font-heading text-xl font-bold text-darktext mb-3">Our Vision</h3>
              <p className="font-paragraph text-darktext/80">
                To be the leading training institute that transforms lives by providing world-class education 
                and creating a skilled workforce ready for the digital future.
              </p>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <Image 
              src="https://static.wixstatic.com/media/04ae4d_ce7ad95647f84c6596a9e5471056040e~mv2.png?originWidth=896&originHeight=576"
              alt="Students collaborating in modern learning environment"
              width={600}
              className="w-full h-96 object-cover rounded-2xl shadow-xl"
            />
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-secondary py-16">
        <div className="max-w-[120rem] mx-auto px-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="font-heading text-4xl lg:text-5xl font-bold text-darktext mb-2">
                  {stat.number}
                </div>
                <div className="font-paragraph text-darktext/70">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="max-w-[120rem] mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <h2 className="font-heading text-4xl font-bold text-darktext mb-4">Our Core Values</h2>
          <p className="font-paragraph text-lg text-darktext/70 max-w-2xl mx-auto">
            The principles that guide our approach to education and student success
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {values.map((value, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="text-center h-full bg-white border-0 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    {value.icon}
                  </div>
                  <CardTitle className="font-heading text-xl text-darktext">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="font-paragraph text-darktext/70">
                    {value.description}
                  </CardDescription>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Team Section */}
      <section className="bg-secondary py-20">
        <div className="max-w-[120rem] mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="font-heading text-4xl font-bold text-darktext mb-4">Meet Our Team</h2>
            <p className="font-paragraph text-lg text-darktext/70 max-w-2xl mx-auto">
              Experienced professionals dedicated to your success
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="text-center bg-white border-0 hover:shadow-xl transition-shadow">
                  <CardHeader>
                    <div className="w-24 h-24 mx-auto mb-4 overflow-hidden rounded-full">
                      <Image 
                        src={member.image}
                        alt={member.name}
                        width={96}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <CardTitle className="font-heading text-xl text-darktext">{member.name}</CardTitle>
                    <CardDescription className="font-paragraph text-primary font-semibold">
                      {member.role}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="font-paragraph text-darktext/70">
                      {member.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="max-w-[120rem] mx-auto px-6 py-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Image 
              src="https://static.wixstatic.com/media/04ae4d_2b99b93dc83e409d93cecc740e9a292c~mv2.png?originWidth=896&originHeight=576"
              alt="Modern training facility with latest technology"
              width={600}
              className="w-full h-96 object-cover rounded-2xl shadow-xl"
            />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-8"
          >
            <div className="space-y-6">
              <h2 className="font-heading text-4xl font-bold text-darktext">Why Choose Our Institute?</h2>
              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <Award className="h-3 w-3 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-semibold text-darktext">Industry-Relevant Curriculum</h3>
                    <p className="font-paragraph text-darktext/70">Our courses are designed with input from industry experts and updated regularly.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <Users className="h-3 w-3 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-semibold text-darktext">Expert Faculty</h3>
                    <p className="font-paragraph text-darktext/70">Learn from experienced professionals with real-world industry experience.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <BookOpen className="h-3 w-3 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-semibold text-darktext">Hands-on Learning</h3>
                    <p className="font-paragraph text-darktext/70">Practical projects and real-world applications to reinforce learning.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <Target className="h-3 w-3 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-semibold text-darktext">Placement Support</h3>
                    <p className="font-paragraph text-darktext/70">Dedicated placement assistance with our network of partner companies.</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-gradient-to-r from-primary to-primary/80 py-20">
        <div className="max-w-[120rem] mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <h2 className="font-heading text-4xl lg:text-5xl font-bold text-darktext">
              Ready to Transform Your Career?
            </h2>
            <p className="font-paragraph text-xl text-darktext/80 max-w-3xl mx-auto">
              Join our community of successful professionals and take the next step in your career journey
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-darktext text-white hover:bg-darktext/90">
                <Link to="/courses">Explore Courses</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="border-buttonborder text-darktext hover:bg-white/10">
                <Link to="/contact">Contact Us</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-gray-900 to-blue-900 text-white py-16">
        <div className="max-w-[120rem] mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center shadow-lg">
                  <span className="text-white font-heading font-bold">IV</span>
                </div>
                <span className="font-heading text-xl font-bold bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">I vision Training</span>
              </div>
              <p className="font-paragraph text-white/70 leading-relaxed">
                Empowering careers through quality education and industry-relevant training programs.
              </p>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4 text-blue-200">Quick Links</h3>
              <div className="space-y-2">
                <Link to="/about" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">About Us</Link>
                <Link to="/courses" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Courses</Link>
                <Link to="/placement" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Placements</Link>
                <Link to="/contact" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Contact</Link>
              </div>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4 text-blue-200">Courses</h3>
              <div className="space-y-2">
                <Link to="/courses/python" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Python Training</Link>
                <Link to="/courses/web-development" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Web Development</Link>
                <Link to="/courses/data-science" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Data Science</Link>
                <Link to="/courses/digital-marketing" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Digital Marketing</Link>
              </div>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4 text-blue-200">Contact Info</h3>
              <div className="space-y-2 font-paragraph text-white/70">
                <p>123 Training Street</p>
                <p>Tech City, TC 12345</p>
                <p>Phone: +1 (555) 123-4567</p>
                <p>Email: info@ivisiontraining.com</p>
              </div>
            </div>
          </div>
          <div className="border-t border-white/20 mt-12 pt-8 text-center">
            <p className="font-paragraph text-white/70">
              © 2024 I vision Training. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}