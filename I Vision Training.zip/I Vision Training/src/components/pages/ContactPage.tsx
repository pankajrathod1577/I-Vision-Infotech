import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Phone, Mail, MapPin, Clock, Send, Upload, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';

interface ContactFormData {
  name: string;
  email: string;
  phone: string;
  course: string;
  message: string;
  resume?: FileList;
}

export default function ContactPage() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const { register, handleSubmit, formState: { errors }, reset } = useForm<ContactFormData>();

  const courses = [
    'Python Training',
    'Web Development',
    'Data Science',
    'Digital Marketing',
    'Other'
  ];

  const onSubmit = async (data: ContactFormData) => {
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    console.log('Form submitted:', data);
    console.log('Resume file:', selectedFile);
    
    setIsSubmitting(false);
    setIsSubmitted(true);
    reset();
    setSelectedFile(null);
    
    // Reset success message after 5 seconds
    setTimeout(() => setIsSubmitted(false), 5000);
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert('File size should be less than 5MB');
        return;
      }
      
      // Check file type
      const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
      if (!allowedTypes.includes(file.type)) {
        alert('Please upload a PDF or Word document');
        return;
      }
      
      setSelectedFile(file);
    }
  };

  const contactInfo = [
    {
      icon: <Phone className="h-6 w-6 text-primary-foreground" />,
      title: "Phone",
      details: ["+1 (555) 123-4567", "+1 (555) 123-4568"],
      description: "Call us for immediate assistance"
    },
    {
      icon: <Mail className="h-6 w-6 text-primary-foreground" />,
      title: "Email",
      details: ["info@ivisiontraining.com", "admissions@ivisiontraining.com"],
      description: "Send us your queries anytime"
    },
    {
      icon: <MapPin className="h-6 w-6 text-primary-foreground" />,
      title: "Address",
      details: ["123 Training Street", "Tech City, TC 12345"],
      description: "Visit our modern campus"
    },
    {
      icon: <Clock className="h-6 w-6 text-primary-foreground" />,
      title: "Office Hours",
      details: ["Mon - Fri: 9:00 AM - 6:00 PM", "Sat: 10:00 AM - 4:00 PM"],
      description: "We're here to help"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="bg-white/95 backdrop-blur-md shadow-lg border-b border-blue-100 sticky top-0 z-50">
        <div className="max-w-[120rem] mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-blue-500 rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white font-heading font-bold text-lg">IV</span>
              </div>
              <span className="font-heading text-2xl font-bold bg-gradient-to-r from-darktext to-blue-600 bg-clip-text text-transparent">I vision Training</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <Link to="/" className="text-darktext hover:text-blue-600 transition-all duration-300 font-paragraph relative group">
                Home
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link to="/about" className="text-darktext hover:text-blue-600 transition-all duration-300 font-paragraph relative group">
                About
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link to="/courses" className="text-darktext hover:text-blue-600 transition-all duration-300 font-paragraph relative group">
                Courses
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link to="/gallery" className="text-darktext hover:text-blue-600 transition-all duration-300 font-paragraph relative group">
                Gallery
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link to="/placement" className="text-darktext hover:text-blue-600 transition-all duration-300 font-paragraph relative group">
                Placement
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link to="/contact" className="text-blue-600 font-paragraph font-semibold relative">
                Contact
                <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-gradient-to-r from-blue-500 to-blue-600"></span>
              </Link>
            </div>
            <Button asChild className="bg-gradient-to-r from-blue-500 to-blue-600 text-white hover:from-blue-600 hover:to-blue-700 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <Link to="/contact">Get Started</Link>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 py-20 overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-indigo-400/20 to-blue-400/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>
        
        <div className="relative max-w-[120rem] mx-auto px-6">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center space-y-6"
          >
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="font-heading text-5xl lg:text-6xl font-bold bg-gradient-to-r from-darktext via-blue-600 to-purple-600 bg-clip-text text-transparent"
            >
              Contact Us
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="font-paragraph text-xl text-darktext/80 max-w-3xl mx-auto leading-relaxed"
            >
              Ready to start your learning journey? Get in touch with us for course inquiries, admissions, or any questions you may have
            </motion.p>
          </motion.div>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="max-w-[120rem] mx-auto px-6 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {contactInfo.map((info, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -10, scale: 1.02 }}
              className="group"
            >
              <Card className="text-center bg-gradient-to-br from-white to-blue-50/50 border-0 hover:shadow-2xl transition-all duration-500 h-full group-hover:border-blue-200">
                <CardHeader>
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                    <div className="text-white">
                      {info.icon}
                    </div>
                  </div>
                  <CardTitle className="font-heading text-lg text-darktext group-hover:text-blue-600 transition-colors duration-300">{info.title}</CardTitle>
                  <CardDescription className="font-paragraph text-darktext/70 text-sm">
                    {info.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    {info.details.map((detail, idx) => (
                      <p key={idx} className="font-paragraph text-darktext text-sm">
                        {detail}
                      </p>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Contact Form and Map Section */}
      <section className="max-w-[120rem] mx-auto px-6 pb-20">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Card className="bg-white border-0 shadow-2xl rounded-3xl overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 border-b border-blue-100">
                <CardTitle className="font-heading text-2xl bg-gradient-to-r from-darktext to-blue-600 bg-clip-text text-transparent">Send us a Message</CardTitle>
                <CardDescription className="font-paragraph text-darktext/70">
                  Fill out the form below and we'll get back to you as soon as possible
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isSubmitted ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-8"
                  >
                    <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                    <h3 className="font-heading text-xl font-bold text-darktext mb-2">
                      Message Sent Successfully!
                    </h3>
                    <p className="font-paragraph text-darktext/70">
                      Thank you for your inquiry. We'll get back to you within 24 hours.
                    </p>
                  </motion.div>
                ) : (
                  <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name" className="font-paragraph text-darktext">Full Name *</Label>
                        <Input
                          id="name"
                          {...register('name', { required: 'Name is required' })}
                          placeholder="Enter your full name"
                          className="border-buttonborder"
                        />
                        {errors.name && (
                          <p className="text-red-500 text-sm font-paragraph">{errors.name.message}</p>
                        )}
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email" className="font-paragraph text-darktext">Email Address *</Label>
                        <Input
                          id="email"
                          type="email"
                          {...register('email', { 
                            required: 'Email is required',
                            pattern: {
                              value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                              message: 'Invalid email address'
                            }
                          })}
                          placeholder="Enter your email"
                          className="border-buttonborder"
                        />
                        {errors.email && (
                          <p className="text-red-500 text-sm font-paragraph">{errors.email.message}</p>
                        )}
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="phone" className="font-paragraph text-darktext">Phone Number</Label>
                        <Input
                          id="phone"
                          {...register('phone')}
                          placeholder="Enter your phone number"
                          className="border-buttonborder"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="course" className="font-paragraph text-darktext">Course of Interest</Label>
                        <Select onValueChange={(value) => register('course').onChange({ target: { value } })}>
                          <SelectTrigger className="border-buttonborder">
                            <SelectValue placeholder="Select a course" />
                          </SelectTrigger>
                          <SelectContent>
                            {courses.map((course) => (
                              <SelectItem key={course} value={course}>
                                {course}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message" className="font-paragraph text-darktext">Message *</Label>
                      <Textarea
                        id="message"
                        {...register('message', { required: 'Message is required' })}
                        placeholder="Tell us about your goals and how we can help you..."
                        rows={4}
                        className="border-buttonborder"
                      />
                      {errors.message && (
                        <p className="text-red-500 text-sm font-paragraph">{errors.message.message}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="resume" className="font-paragraph text-darktext">Upload Resume (Optional)</Label>
                      <div className="border-2 border-dashed border-buttonborder rounded-lg p-6 text-center">
                        <input
                          id="resume"
                          type="file"
                          accept=".pdf,.doc,.docx"
                          onChange={handleFileChange}
                          className="hidden"
                        />
                        <Label htmlFor="resume" className="cursor-pointer">
                          <Upload className="h-8 w-8 text-darktext/50 mx-auto mb-2" />
                          <p className="font-paragraph text-darktext/70 text-sm">
                            {selectedFile ? selectedFile.name : 'Click to upload or drag and drop'}
                          </p>
                          <p className="font-paragraph text-darktext/50 text-xs mt-1">
                            PDF, DOC, DOCX (Max 5MB)
                          </p>
                        </Label>
                      </div>
                    </div>

                    <Button 
                      type="submit" 
                      disabled={isSubmitting}
                      className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send className="h-4 w-4 mr-2" />
                          Send Message
                        </>
                      )}
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Map and Additional Info */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-8"
          >
            {/* Map Placeholder */}
            <Card className="bg-white border-0 shadow-2xl rounded-3xl overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 border-b border-blue-100">
                <CardTitle className="font-heading text-xl bg-gradient-to-r from-darktext to-blue-600 bg-clip-text text-transparent">Find Us</CardTitle>
                <CardDescription className="font-paragraph text-darktext/70">
                  Visit our campus for a tour and meet our team
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl h-64 flex items-center justify-center border border-blue-100">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                      <MapPin className="h-8 w-8 text-white" />
                    </div>
                    <p className="font-paragraph text-darktext/70 font-semibold">
                      Interactive map would be integrated here
                    </p>
                    <p className="font-paragraph text-sm text-darktext/50 mt-2">
                      123 Training Street, Tech City, TC 12345
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* FAQ Section */}
            <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-0 rounded-3xl">
              <CardHeader>
                <CardTitle className="font-heading text-xl bg-gradient-to-r from-darktext to-blue-600 bg-clip-text text-transparent">Frequently Asked Questions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-heading text-sm font-semibold text-darktext mb-1">
                    What are the admission requirements?
                  </h4>
                  <p className="font-paragraph text-sm text-darktext/70">
                    Basic computer knowledge and enthusiasm to learn. No prior programming experience required.
                  </p>
                </div>
                <div>
                  <h4 className="font-heading text-sm font-semibold text-darktext mb-1">
                    Do you provide placement assistance?
                  </h4>
                  <p className="font-paragraph text-sm text-darktext/70">
                    Yes, we have a dedicated placement team with 95% success rate and partnerships with 50+ companies.
                  </p>
                </div>
                <div>
                  <h4 className="font-heading text-sm font-semibold text-darktext mb-1">
                    Are there flexible timing options?
                  </h4>
                  <p className="font-paragraph text-sm text-darktext/70">
                    We offer weekday, weekend, and evening batches to accommodate working professionals.
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="relative bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-700 py-20 overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-1/4 w-64 h-64 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-0 right-1/4 w-48 h-48 bg-white/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>
        
        <div className="relative max-w-[120rem] mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="font-heading text-4xl lg:text-5xl font-bold text-white"
            >
              Ready to Transform Your Career?
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="font-paragraph text-xl text-white/90 max-w-3xl mx-auto leading-relaxed"
            >
              Don't wait any longer. Start your journey with us today and join thousands of successful professionals.
            </motion.p>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-gray-100 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 font-semibold">
                <Link to="/courses">View Courses</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="border-2 border-white text-white hover:bg-white/10 hover:border-white transition-all duration-300 transform hover:scale-105">
                <Link to="/placement">See Success Stories</Link>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-gray-900 to-blue-900 text-white py-16">
        <div className="max-w-[120rem] mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center shadow-lg">
                  <span className="text-white font-heading font-bold">IV</span>
                </div>
                <span className="font-heading text-xl font-bold bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">I vision Training</span>
              </div>
              <p className="font-paragraph text-white/70 leading-relaxed">
                Empowering careers through quality education and industry-relevant training programs.
              </p>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4 text-blue-200">Quick Links</h3>
              <div className="space-y-2">
                <Link to="/about" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">About Us</Link>
                <Link to="/courses" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Courses</Link>
                <Link to="/placement" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Placements</Link>
                <Link to="/contact" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Contact</Link>
              </div>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4 text-blue-200">Courses</h3>
              <div className="space-y-2">
                <Link to="/courses/python" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Python Training</Link>
                <Link to="/courses/web-development" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Web Development</Link>
                <Link to="/courses/data-science" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Data Science</Link>
                <Link to="/courses/digital-marketing" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Digital Marketing</Link>
              </div>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4 text-blue-200">Contact Info</h3>
              <div className="space-y-2 font-paragraph text-white/70">
                <p>123 Training Street</p>
                <p>Tech City, TC 12345</p>
                <p>Phone: +1 (555) 123-4567</p>
                <p>Email: info@ivisiontraining.com</p>
              </div>
            </div>
          </div>
          <div className="border-t border-white/20 mt-12 pt-8 text-center">
            <p className="font-paragraph text-white/70">
              © 2024 I vision Training. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}