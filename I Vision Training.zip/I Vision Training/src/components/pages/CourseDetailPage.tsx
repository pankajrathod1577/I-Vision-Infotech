import { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Image } from '@/components/ui/image';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Clock, Users, Award, BookOpen, CheckCircle, Star, ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import { BaseCrudService } from '@/integrations';
import { Courses } from '@/entities';

export default function CourseDetailPage() {
  const { courseType } = useParams<{ courseType: string }>();
  const [course, setCourse] = useState<Courses | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCourse = async () => {
      try {
        const { items } = await BaseCrudService.getAll<Courses>('courses');
        
        // Convert URL parameter back to course type
        const formattedCourseType = courseType?.split('-').map(word => 
          word.charAt(0).toUpperCase() + word.slice(1)
        ).join(' ');
        
        const foundCourse = items.find(c => c.courseType === formattedCourseType);
        setCourse(foundCourse || null);
      } catch (error) {
        console.error('Error fetching course:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCourse();
  }, [courseType]);

  // Default course data if not found in database
  const defaultCourseData = {
    'python': {
      courseName: 'Python Programming Training',
      courseDescription: 'Master Python programming from basics to advanced concepts with hands-on projects and real-world applications.',
      courseDuration: '3 months',
      coursePrice: 15000,
      learningOutcomes: 'Learn Python syntax, data structures, OOP, web frameworks, data analysis, and automation.',
      modules: [
        'Python Fundamentals & Syntax',
        'Data Structures & Algorithms',
        'Object-Oriented Programming',
        'Web Development with Django/Flask',
        'Data Analysis with Pandas',
        'API Development & Integration',
        'Testing & Debugging',
        'Project Development'
      ],
      prerequisites: ['Basic computer knowledge', 'Logical thinking ability'],
      certification: 'Industry-recognized Python Developer Certificate',
      careerOpportunities: ['Python Developer', 'Backend Developer', 'Data Analyst', 'Automation Engineer']
    },
    'web-development': {
      courseName: 'Full Stack Web Development',
      courseDescription: 'Complete web development course covering frontend, backend, and database technologies.',
      courseDuration: '4 months',
      coursePrice: 20000,
      learningOutcomes: 'Build responsive websites, web applications, and RESTful APIs using modern technologies.',
      modules: [
        'HTML5 & CSS3 Fundamentals',
        'JavaScript & ES6+',
        'React.js Development',
        'Node.js & Express.js',
        'Database Design & MongoDB',
        'RESTful API Development',
        'Authentication & Security',
        'Deployment & DevOps'
      ],
      prerequisites: ['Basic computer skills', 'Understanding of internet concepts'],
      certification: 'Full Stack Web Developer Certificate',
      careerOpportunities: ['Frontend Developer', 'Backend Developer', 'Full Stack Developer', 'Web Application Developer']
    },
    'data-science': {
      courseName: 'Data Science & Analytics',
      courseDescription: 'Comprehensive data science program covering statistics, machine learning, and data visualization.',
      courseDuration: '6 months',
      coursePrice: 25000,
      learningOutcomes: 'Analyze data, build predictive models, and create insights using Python and R.',
      modules: [
        'Statistics & Probability',
        'Python for Data Science',
        'Data Cleaning & Preprocessing',
        'Exploratory Data Analysis',
        'Machine Learning Algorithms',
        'Deep Learning Basics',
        'Data Visualization',
        'Capstone Project'
      ],
      prerequisites: ['Basic mathematics', 'Programming fundamentals'],
      certification: 'Certified Data Scientist',
      careerOpportunities: ['Data Scientist', 'Data Analyst', 'ML Engineer', 'Business Intelligence Analyst']
    },
    'digital-marketing': {
      courseName: 'Digital Marketing Mastery',
      courseDescription: 'Complete digital marketing course covering SEO, social media, PPC, and analytics.',
      courseDuration: '2 months',
      coursePrice: 12000,
      learningOutcomes: 'Create effective digital marketing campaigns and measure their success.',
      modules: [
        'Digital Marketing Fundamentals',
        'Search Engine Optimization (SEO)',
        'Social Media Marketing',
        'Pay-Per-Click (PPC) Advertising',
        'Content Marketing Strategy',
        'Email Marketing',
        'Analytics & Reporting',
        'Campaign Management'
      ],
      prerequisites: ['Basic internet knowledge', 'Communication skills'],
      certification: 'Digital Marketing Professional Certificate',
      careerOpportunities: ['Digital Marketing Specialist', 'SEO Analyst', 'Social Media Manager', 'PPC Specialist']
    }
  };

  const courseData = course || defaultCourseData[courseType as keyof typeof defaultCourseData];

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="font-paragraph text-darktext/70">Loading course details...</p>
        </div>
      </div>
    );
  }

  if (!courseData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-heading text-2xl font-bold text-darktext mb-4">Course Not Found</h1>
          <p className="font-paragraph text-darktext/70 mb-6">The course you're looking for doesn't exist.</p>
          <Button asChild>
            <Link to="/courses">Back to Courses</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-[120rem] mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-heading font-bold text-lg">TI</span>
              </div>
              <span className="font-heading text-xl font-bold text-darktext">Training Institute</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <Link to="/" className="text-darktext hover:text-primary transition-colors font-paragraph">Home</Link>
              <Link to="/about" className="text-darktext hover:text-primary transition-colors font-paragraph">About</Link>
              <Link to="/courses" className="text-primary font-paragraph font-semibold">Courses</Link>
              <Link to="/gallery" className="text-darktext hover:text-primary transition-colors font-paragraph">Gallery</Link>
              <Link to="/placement" className="text-darktext hover:text-primary transition-colors font-paragraph">Placement</Link>
              <Link to="/contact" className="text-darktext hover:text-primary transition-colors font-paragraph">Contact</Link>
            </div>
            <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Link to="/contact">Get Started</Link>
            </Button>
          </div>
        </div>
      </nav>

      {/* Breadcrumb */}
      <section className="bg-secondary py-4">
        <div className="max-w-[120rem] mx-auto px-6">
          <div className="flex items-center space-x-2 text-sm">
            <Link to="/" className="font-paragraph text-darktext/70 hover:text-primary">Home</Link>
            <span className="text-darktext/50">/</span>
            <Link to="/courses" className="font-paragraph text-darktext/70 hover:text-primary">Courses</Link>
            <span className="text-darktext/50">/</span>
            <span className="font-paragraph text-darktext">{courseData.courseName}</span>
          </div>
        </div>
      </section>

      {/* Course Header */}
      <section className="max-w-[120rem] mx-auto px-6 py-12">
        <div className="grid lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2 space-y-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Button asChild variant="outline" className="mb-6">
                <Link to="/courses">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Courses
                </Link>
              </Button>
              
              <div className="space-y-4">
                <Badge className="bg-primary text-primary-foreground">
                  {course?.courseType || courseType?.split('-').map(word => 
                    word.charAt(0).toUpperCase() + word.slice(1)
                  ).join(' ')}
                </Badge>
                <h1 className="font-heading text-4xl lg:text-5xl font-bold text-darktext">
                  {courseData.courseName}
                </h1>
                <p className="font-paragraph text-lg text-darktext/80 leading-relaxed">
                  {courseData.courseDescription}
                </p>
              </div>

              <div className="flex flex-wrap gap-6 text-sm text-darktext/70">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4" />
                  <span className="font-paragraph">{courseData.courseDuration}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4" />
                  <span className="font-paragraph">Small batches (15-20 students)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Award className="h-4 w-4" />
                  <span className="font-paragraph">Certificate included</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Star className="h-4 w-4" />
                  <span className="font-paragraph">4.8/5 rating</span>
                </div>
              </div>
            </motion.div>

            {/* Course Image */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <Image 
                src={course?.courseThumbnail || 'https://static.wixstatic.com/media/04ae4d_e6aa0e1a42504124a3051eab25f0dcaa~mv2.png?originWidth=768&originHeight=320'}
                alt={courseData.courseName}
                width={800}
                className="w-full h-64 lg:h-80 object-cover rounded-2xl shadow-xl"
              />
            </motion.div>
          </div>

          {/* Enrollment Card */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="lg:col-span-1"
          >
            <Card className="sticky top-6 bg-white border-0 shadow-xl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="font-heading text-2xl text-darktext">
                    ₹{courseData.coursePrice?.toLocaleString() || '15,000'}
                  </CardTitle>
                  <Badge className="bg-green-100 text-green-800">
                    Limited Seats
                  </Badge>
                </div>
                <CardDescription className="font-paragraph text-darktext/70">
                  One-time payment, lifetime access to materials
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-paragraph text-darktext/70">Duration</span>
                    <span className="font-paragraph text-darktext font-semibold">{courseData.courseDuration}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-paragraph text-darktext/70">Format</span>
                    <span className="font-paragraph text-darktext font-semibold">Classroom + Online</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-paragraph text-darktext/70">Certificate</span>
                    <span className="font-paragraph text-darktext font-semibold">Yes</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-paragraph text-darktext/70">Placement Support</span>
                    <span className="font-paragraph text-darktext font-semibold">Included</span>
                  </div>
                </div>

                <div className="space-y-3">
                  <Button asChild className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                    <Link to="/contact">Enroll Now</Link>
                  </Button>
                  <Button asChild variant="outline" className="w-full border-buttonborder">
                    <Link to="/contact">Download Syllabus</Link>
                  </Button>
                </div>

                <div className="bg-contentblockbackground p-4 rounded-lg">
                  <h4 className="font-heading text-sm font-semibold text-darktext mb-2">
                    Next Batch Starts
                  </h4>
                  <p className="font-paragraph text-darktext/80 text-sm">
                    December 15, 2024
                  </p>
                  <p className="font-paragraph text-darktext/70 text-xs mt-1">
                    Weekend & Evening batches available
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Course Details Tabs */}
      <section className="max-w-[120rem] mx-auto px-6 pb-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <Tabs defaultValue="overview" className="space-y-8">
            <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
              <TabsTrigger value="requirements">Requirements</TabsTrigger>
              <TabsTrigger value="career">Career Path</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-8">
              <Card className="bg-white border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="font-heading text-2xl text-darktext">Course Overview</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="font-heading text-lg font-semibold text-darktext mb-3">
                      What You'll Learn
                    </h3>
                    <p className="font-paragraph text-darktext/80 leading-relaxed">
                      {courseData.learningOutcomes}
                    </p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-heading text-base font-semibold text-darktext mb-3">
                        Course Features
                      </h4>
                      <ul className="space-y-2">
                        {[
                          'Hands-on practical projects',
                          'Industry expert instructors',
                          'Small batch sizes',
                          'Flexible timing options',
                          'Lifetime course access',
                          'Job placement assistance'
                        ].map((feature, index) => (
                          <li key={index} className="flex items-center space-x-2">
                            <CheckCircle className="h-4 w-4 text-green-500" />
                            <span className="font-paragraph text-darktext/80 text-sm">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-heading text-base font-semibold text-darktext mb-3">
                        Learning Format
                      </h4>
                      <ul className="space-y-2">
                        {[
                          'Interactive classroom sessions',
                          'Online learning portal',
                          'Live coding demonstrations',
                          'Group projects & assignments',
                          'One-on-one mentoring',
                          'Regular assessments'
                        ].map((format, index) => (
                          <li key={index} className="flex items-center space-x-2">
                            <CheckCircle className="h-4 w-4 text-green-500" />
                            <span className="font-paragraph text-darktext/80 text-sm">{format}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="curriculum" className="space-y-8">
              <Card className="bg-white border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="font-heading text-2xl text-darktext">Course Curriculum</CardTitle>
                  <CardDescription className="font-paragraph text-darktext/70">
                    Comprehensive modules designed to take you from beginner to professional
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {(courseData as any).modules?.map((module: string, index: number) => (
                      <div key={index} className="flex items-start space-x-4 p-4 bg-secondary rounded-lg">
                        <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="font-heading text-sm font-bold text-primary-foreground">
                            {index + 1}
                          </span>
                        </div>
                        <div>
                          <h4 className="font-heading text-base font-semibold text-darktext">
                            {module}
                          </h4>
                          <p className="font-paragraph text-sm text-darktext/70 mt-1">
                            Comprehensive coverage with practical exercises and real-world examples
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="requirements" className="space-y-8">
              <Card className="bg-white border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="font-heading text-2xl text-darktext">Prerequisites & Requirements</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="font-heading text-lg font-semibold text-darktext mb-3">
                      Prerequisites
                    </h3>
                    <ul className="space-y-2">
                      {(courseData as any).prerequisites?.map((req: string, index: number) => (
                        <li key={index} className="flex items-center space-x-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span className="font-paragraph text-darktext/80">{req}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-heading text-lg font-semibold text-darktext mb-3">
                      Technical Requirements
                    </h3>
                    <ul className="space-y-2">
                      {[
                        'Laptop/Desktop with minimum 4GB RAM',
                        'Stable internet connection',
                        'Willingness to learn and practice',
                        'Commitment to attend classes regularly'
                      ].map((req, index) => (
                        <li key={index} className="flex items-center space-x-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span className="font-paragraph text-darktext/80">{req}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-contentblockbackground p-4 rounded-lg">
                    <h4 className="font-heading text-base font-semibold text-darktext mb-2">
                      Certification
                    </h4>
                    <p className="font-paragraph text-darktext/80 text-sm">
                      {(courseData as any).certification || 'Industry-recognized certificate upon successful completion'}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="career" className="space-y-8">
              <Card className="bg-white border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="font-heading text-2xl text-darktext">Career Opportunities</CardTitle>
                  <CardDescription className="font-paragraph text-darktext/70">
                    Explore the career paths available after completing this course
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="font-heading text-lg font-semibold text-darktext mb-4">
                      Job Roles You Can Apply For
                    </h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      {(courseData as any).careerOpportunities?.map((role: string, index: number) => (
                        <div key={index} className="flex items-center space-x-3 p-3 bg-secondary rounded-lg">
                          <Award className="h-5 w-5 text-primary" />
                          <span className="font-paragraph text-darktext font-semibold">{role}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <div className="font-heading text-2xl font-bold text-darktext">₹4-8 LPA</div>
                      <div className="font-paragraph text-sm text-darktext/70">Starting Salary</div>
                    </div>
                    <div className="text-center">
                      <div className="font-heading text-2xl font-bold text-darktext">95%</div>
                      <div className="font-paragraph text-sm text-darktext/70">Placement Rate</div>
                    </div>
                    <div className="text-center">
                      <div className="font-heading text-2xl font-bold text-darktext">50+</div>
                      <div className="font-paragraph text-sm text-darktext/70">Hiring Partners</div>
                    </div>
                  </div>

                  <div className="bg-contentblockbackground p-6 rounded-lg">
                    <h4 className="font-heading text-base font-semibold text-darktext mb-3">
                      Placement Support Includes
                    </h4>
                    <ul className="space-y-2">
                      {[
                        'Resume building and optimization',
                        'Mock interview sessions',
                        'Technical interview preparation',
                        'Soft skills development',
                        'Job referrals to partner companies',
                        'Career counseling and guidance'
                      ].map((support, index) => (
                        <li key={index} className="flex items-center space-x-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span className="font-paragraph text-darktext/80 text-sm">{support}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </section>

      {/* Call to Action */}
      <section className="bg-gradient-to-r from-primary to-primary/80 py-20">
        <div className="max-w-[120rem] mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <h2 className="font-heading text-4xl lg:text-5xl font-bold text-darktext">
              Ready to Start Learning?
            </h2>
            <p className="font-paragraph text-xl text-darktext/80 max-w-3xl mx-auto">
              Join thousands of successful students who have transformed their careers with our training programs
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-darktext text-white hover:bg-darktext/90">
                <Link to="/contact">Enroll Now</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="border-buttonborder text-darktext hover:bg-white/10">
                <Link to="/placement">View Success Stories</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-darktext text-white py-16">
        <div className="max-w-[120rem] mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-primary-foreground font-heading font-bold">TI</span>
                </div>
                <span className="font-heading text-lg font-bold">Training Institute</span>
              </div>
              <p className="font-paragraph text-white/70">
                Empowering careers through quality education and industry-relevant training programs.
              </p>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4">Quick Links</h3>
              <div className="space-y-2">
                <Link to="/about" className="block font-paragraph text-white/70 hover:text-white transition-colors">About Us</Link>
                <Link to="/courses" className="block font-paragraph text-white/70 hover:text-white transition-colors">Courses</Link>
                <Link to="/placement" className="block font-paragraph text-white/70 hover:text-white transition-colors">Placements</Link>
                <Link to="/contact" className="block font-paragraph text-white/70 hover:text-white transition-colors">Contact</Link>
              </div>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4">Courses</h3>
              <div className="space-y-2">
                <Link to="/courses/python" className="block font-paragraph text-white/70 hover:text-white transition-colors">Python Training</Link>
                <Link to="/courses/web-development" className="block font-paragraph text-white/70 hover:text-white transition-colors">Web Development</Link>
                <Link to="/courses/data-science" className="block font-paragraph text-white/70 hover:text-white transition-colors">Data Science</Link>
                <Link to="/courses/digital-marketing" className="block font-paragraph text-white/70 hover:text-white transition-colors">Digital Marketing</Link>
              </div>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4">Contact Info</h3>
              <div className="space-y-2 font-paragraph text-white/70">
                <p>123 Training Street</p>
                <p>Tech City, TC 12345</p>
                <p>Phone: +1 (555) 123-4567</p>
                <p>Email: info@traininginstitute.com</p>
              </div>
            </div>
          </div>
          <div className="border-t border-white/20 mt-12 pt-8 text-center">
            <p className="font-paragraph text-white/70">
              © 2024 Training Institute. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}