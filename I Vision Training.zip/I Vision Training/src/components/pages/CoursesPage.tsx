import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Image } from '@/components/ui/image';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Clock, Users, Award, BookOpen, Filter } from 'lucide-react';
import { motion } from 'framer-motion';
import { BaseCrudService } from '@/integrations';
import { Courses } from '@/entities';

export default function CoursesPage() {
  const [courses, setCourses] = useState<Courses[]>([]);
  const [filteredCourses, setFilteredCourses] = useState<Courses[]>([]);
  const [selectedType, setSelectedType] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  const courseTypes = [
    { value: 'all', label: 'All Courses' },
    { value: 'Programming', label: 'Programming' },
    { value: 'Web Development', label: 'Web Development' },
    { value: 'Data Science', label: 'Data Science' },
    { value: 'Digital Marketing', label: 'Digital Marketing' }
  ];

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const { items } = await BaseCrudService.getAll<Courses>('courses');
        setCourses(items);
        setFilteredCourses(items);
      } catch (error) {
        console.error('Error fetching courses:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCourses();
  }, []);

  useEffect(() => {
    if (selectedType === 'all') {
      setFilteredCourses(courses);
    } else {
      setFilteredCourses(courses.filter(course => course.courseType === selectedType));
    }
  }, [selectedType, courses]);

  const handleTypeChange = (value: string) => {
    setSelectedType(value);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="font-paragraph text-darktext/70">Loading courses...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-[120rem] mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-heading font-bold text-lg">TI</span>
              </div>
              <span className="font-heading text-xl font-bold text-darktext">Training Institute</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <Link to="/" className="text-darktext hover:text-primary transition-colors font-paragraph">Home</Link>
              <Link to="/about" className="text-darktext hover:text-primary transition-colors font-paragraph">About</Link>
              <Link to="/courses" className="text-primary font-paragraph font-semibold">Courses</Link>
              <Link to="/gallery" className="text-darktext hover:text-primary transition-colors font-paragraph">Gallery</Link>
              <Link to="/placement" className="text-darktext hover:text-primary transition-colors font-paragraph">Placement</Link>
              <Link to="/contact" className="text-darktext hover:text-primary transition-colors font-paragraph">Contact</Link>
            </div>
            <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Link to="/contact">Get Started</Link>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary via-primary/80 to-secondary py-20">
        <div className="max-w-[120rem] mx-auto px-6">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center space-y-6"
          >
            <h1 className="font-heading text-5xl lg:text-6xl font-bold text-darktext">
              Our Training Courses
            </h1>
            <p className="font-paragraph text-xl text-darktext/80 max-w-3xl mx-auto">
              Comprehensive training programs designed to boost your career with industry-relevant skills and hands-on experience
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filter Section */}
      <section className="max-w-[120rem] mx-auto px-6 py-12">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-2">
            <h2 className="font-heading text-2xl font-bold text-darktext">
              Browse Courses ({filteredCourses.length})
            </h2>
            <p className="font-paragraph text-darktext/70">
              Find the perfect course to advance your career
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <Filter className="h-5 w-5 text-darktext/70" />
            <Select value={selectedType} onValueChange={handleTypeChange}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                {courseTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </section>

      {/* Courses Grid */}
      <section className="max-w-[120rem] mx-auto px-6 pb-20">
        {filteredCourses.length === 0 ? (
          <div className="text-center py-16">
            <BookOpen className="h-16 w-16 text-darktext/30 mx-auto mb-4" />
            <h3 className="font-heading text-xl font-bold text-darktext mb-2">No courses found</h3>
            <p className="font-paragraph text-darktext/70">
              Try selecting a different course type or check back later for new courses.
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredCourses.map((course, index) => (
              <motion.div
                key={course._id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 bg-white border-0 h-full flex flex-col">
                  <div className="relative">
                    <Image 
                      src={course.courseThumbnail || "https://static.wixstatic.com/media/04ae4d_5fc0febeffe94c64841227705973decd~mv2.png?originWidth=384&originHeight=192"}
                      alt={course.courseName || "Course thumbnail"}
                      width={400}
                      className="w-full h-48 object-cover"
                    />
                    <div className="absolute top-4 left-4">
                      <Badge className="bg-primary text-primary-foreground">
                        {course.courseType}
                      </Badge>
                    </div>
                    {course.coursePrice && (
                      <div className="absolute top-4 right-4">
                        <Badge className="bg-darktext text-white">
                          ${course.coursePrice}
                        </Badge>
                      </div>
                    )}
                  </div>
                  <CardHeader className="flex-grow">
                    <CardTitle className="font-heading text-xl text-darktext line-clamp-2">
                      {course.courseName}
                    </CardTitle>
                    <CardDescription className="font-paragraph text-darktext/70 line-clamp-3">
                      {course.courseDescription}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between text-sm text-darktext/70">
                      <div className="flex items-center space-x-1">
                        <Clock className="h-4 w-4" />
                        <span className="font-paragraph">{course.courseDuration || "Duration varies"}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Users className="h-4 w-4" />
                        <span className="font-paragraph">Small batches</span>
                      </div>
                    </div>
                    {course.learningOutcomes && (
                      <div className="space-y-2">
                        <h4 className="font-heading text-sm font-semibold text-darktext">Key Learning Outcomes:</h4>
                        <p className="font-paragraph text-sm text-darktext/70 line-clamp-2">
                          {course.learningOutcomes}
                        </p>
                      </div>
                    )}
                    <Button 
                      asChild 
                      className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                    >
                      <Link to={`/courses/${course.courseType?.toLowerCase().replace(/\s+/g, '-')}`}>
                        Learn More
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </section>

      {/* Features Section */}
      <section className="bg-secondary py-20">
        <div className="max-w-[120rem] mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="font-heading text-4xl font-bold text-darktext mb-4">Why Choose Our Courses?</h2>
            <p className="font-paragraph text-lg text-darktext/70 max-w-2xl mx-auto">
              Our training programs are designed with industry best practices and real-world applications
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <BookOpen className="h-8 w-8 text-primary-foreground" />,
                title: "Comprehensive Curriculum",
                description: "Industry-relevant content updated regularly"
              },
              {
                icon: <Users className="h-8 w-8 text-primary-foreground" />,
                title: "Expert Instructors",
                description: "Learn from experienced professionals"
              },
              {
                icon: <Award className="h-8 w-8 text-primary-foreground" />,
                title: "Certification",
                description: "Receive recognized certificates upon completion"
              },
              {
                icon: <Clock className="h-8 w-8 text-primary-foreground" />,
                title: "Flexible Schedule",
                description: "Weekend and evening batches available"
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="text-center h-full bg-white border-0 hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                      {feature.icon}
                    </div>
                    <CardTitle className="font-heading text-xl text-darktext">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="font-paragraph text-darktext/70">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-gradient-to-r from-primary to-primary/80 py-20">
        <div className="max-w-[120rem] mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <h2 className="font-heading text-4xl lg:text-5xl font-bold text-darktext">
              Ready to Start Learning?
            </h2>
            <p className="font-paragraph text-xl text-darktext/80 max-w-3xl mx-auto">
              Join thousands of successful students who have transformed their careers with our training programs
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-darktext text-white hover:bg-darktext/90">
                <Link to="/contact">Enroll Now</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="border-buttonborder text-darktext hover:bg-white/10">
                <Link to="/placement">View Placements</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-darktext text-white py-16">
        <div className="max-w-[120rem] mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-primary-foreground font-heading font-bold">TI</span>
                </div>
                <span className="font-heading text-lg font-bold">Training Institute</span>
              </div>
              <p className="font-paragraph text-white/70">
                Empowering careers through quality education and industry-relevant training programs.
              </p>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4">Quick Links</h3>
              <div className="space-y-2">
                <Link to="/about" className="block font-paragraph text-white/70 hover:text-white transition-colors">About Us</Link>
                <Link to="/courses" className="block font-paragraph text-white/70 hover:text-white transition-colors">Courses</Link>
                <Link to="/placement" className="block font-paragraph text-white/70 hover:text-white transition-colors">Placements</Link>
                <Link to="/contact" className="block font-paragraph text-white/70 hover:text-white transition-colors">Contact</Link>
              </div>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4">Courses</h3>
              <div className="space-y-2">
                <Link to="/courses/python" className="block font-paragraph text-white/70 hover:text-white transition-colors">Python Training</Link>
                <Link to="/courses/web-development" className="block font-paragraph text-white/70 hover:text-white transition-colors">Web Development</Link>
                <Link to="/courses/data-science" className="block font-paragraph text-white/70 hover:text-white transition-colors">Data Science</Link>
                <Link to="/courses/digital-marketing" className="block font-paragraph text-white/70 hover:text-white transition-colors">Digital Marketing</Link>
              </div>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4">Contact Info</h3>
              <div className="space-y-2 font-paragraph text-white/70">
                <p>123 Training Street</p>
                <p>Tech City, TC 12345</p>
                <p>Phone: +1 (555) 123-4567</p>
                <p>Email: info@traininginstitute.com</p>
              </div>
            </div>
          </div>
          <div className="border-t border-white/20 mt-12 pt-8 text-center">
            <p className="font-paragraph text-white/70">
              © 2024 Training Institute. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}