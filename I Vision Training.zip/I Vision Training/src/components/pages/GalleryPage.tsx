import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Image } from '@/components/ui/image';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, MapPin, Filter, Camera } from 'lucide-react';
import { motion } from 'framer-motion';
import { BaseCrudService } from '@/integrations';
import { GalleryItems } from '@/entities';
import { format } from 'date-fns';

export default function GalleryPage() {
  const [galleryItems, setGalleryItems] = useState<GalleryItems[]>([]);
  const [filteredItems, setFilteredItems] = useState<GalleryItems[]>([]);
  const [selectedType, setSelectedType] = useState<string>('all');
  const [loading, setLoading] = useState(true);
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);

  useEffect(() => {
    const fetchGalleryItems = async () => {
      try {
        const { items } = await BaseCrudService.getAll<GalleryItems>('galleryitems');
        setGalleryItems(items);
        setFilteredItems(items);
      } catch (error) {
        console.error('Error fetching gallery items:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchGalleryItems();
  }, []);

  // Get unique activity types for filter
  const activityTypes = [
    { value: 'all', label: 'All Activities' },
    ...Array.from(new Set(galleryItems.map(item => item.activityType).filter(Boolean)))
      .map(type => ({ value: type!, label: type! }))
  ];

  useEffect(() => {
    if (selectedType === 'all') {
      setFilteredItems(galleryItems);
    } else {
      setFilteredItems(galleryItems.filter(item => item.activityType === selectedType));
    }
  }, [selectedType, galleryItems]);

  const handleTypeChange = (value: string) => {
    setSelectedType(value);
  };

  const formatDate = (date: Date | string | undefined) => {
    if (!date) return 'Date not specified';
    try {
      const dateObj = typeof date === 'string' ? new Date(date) : date;
      return format(dateObj, 'MMM dd, yyyy');
    } catch {
      return 'Date not specified';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="font-paragraph text-darktext/70">Loading gallery...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-[120rem] mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-heading font-bold text-lg">TI</span>
              </div>
              <span className="font-heading text-xl font-bold text-darktext">Training Institute</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <Link to="/" className="text-darktext hover:text-primary transition-colors font-paragraph">Home</Link>
              <Link to="/about" className="text-darktext hover:text-primary transition-colors font-paragraph">About</Link>
              <Link to="/courses" className="text-darktext hover:text-primary transition-colors font-paragraph">Courses</Link>
              <Link to="/gallery" className="text-primary font-paragraph font-semibold">Gallery</Link>
              <Link to="/placement" className="text-darktext hover:text-primary transition-colors font-paragraph">Placement</Link>
              <Link to="/contact" className="text-darktext hover:text-primary transition-colors font-paragraph">Contact</Link>
            </div>
            <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Link to="/contact">Get Started</Link>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary via-primary/80 to-secondary py-20">
        <div className="max-w-[120rem] mx-auto px-6">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center space-y-6"
          >
            <h1 className="font-heading text-5xl lg:text-6xl font-bold text-darktext">
              Our Gallery
            </h1>
            <p className="font-paragraph text-xl text-darktext/80 max-w-3xl mx-auto">
              Explore moments from our training sessions, events, and celebrations that showcase our vibrant learning community
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filter Section */}
      <section className="max-w-[120rem] mx-auto px-6 py-12">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-2">
            <h2 className="font-heading text-2xl font-bold text-darktext">
              Browse Gallery ({filteredItems.length} {filteredItems.length === 1 ? 'item' : 'items'})
            </h2>
            <p className="font-paragraph text-darktext/70">
              Hover over photos to see activity details
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <Filter className="h-5 w-5 text-darktext/70" />
            <Select value={selectedType} onValueChange={handleTypeChange}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by activity" />
              </SelectTrigger>
              <SelectContent>
                {activityTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="max-w-[120rem] mx-auto px-6 pb-20">
        {filteredItems.length === 0 ? (
          <div className="text-center py-16">
            <Camera className="h-16 w-16 text-darktext/30 mx-auto mb-4" />
            <h3 className="font-heading text-xl font-bold text-darktext mb-2">No photos found</h3>
            <p className="font-paragraph text-darktext/70">
              Try selecting a different activity type or check back later for new photos.
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredItems.map((item, index) => (
              <motion.div
                key={item._id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.05 }}
                onMouseEnter={() => setHoveredItem(item._id)}
                onMouseLeave={() => setHoveredItem(null)}
                className="group cursor-pointer"
              >
                <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 bg-white border-0">
                  <div className="relative aspect-square">
                    <Image 
                      src={item.photo || "https://static.wixstatic.com/media/04ae4d_cc471a7fbec54dafb5567da5f61281cb~mv2.png?originWidth=256&originHeight=256"}
                      alt={item.title || "Gallery image"}
                      width={300}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    
                    {/* Activity Type Badge */}
                    {item.activityType && (
                      <div className="absolute top-3 left-3">
                        <Badge className="bg-primary/90 text-primary-foreground backdrop-blur-sm">
                          {item.activityType}
                        </Badge>
                      </div>
                    )}

                    {/* Hover Overlay */}
                    <div className={`absolute inset-0 bg-darktext/80 transition-opacity duration-300 ${
                      hoveredItem === item._id ? 'opacity-100' : 'opacity-0'
                    }`}>
                      <div className="absolute inset-0 flex flex-col justify-center items-center text-white p-4 text-center">
                        {item.title && (
                          <h3 className="font-heading text-lg font-bold mb-2 line-clamp-2">
                            {item.title}
                          </h3>
                        )}
                        {item.description && (
                          <p className="font-paragraph text-sm mb-3 line-clamp-3 opacity-90">
                            {item.description}
                          </p>
                        )}
                        <div className="space-y-1 text-xs opacity-80">
                          {item.eventDate && (
                            <div className="flex items-center justify-center space-x-1">
                              <Calendar className="h-3 w-3" />
                              <span className="font-paragraph">{formatDate(item.eventDate)}</span>
                            </div>
                          )}
                          {item.location && (
                            <div className="flex items-center justify-center space-x-1">
                              <MapPin className="h-3 w-3" />
                              <span className="font-paragraph">{item.location}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Card Content - Always Visible */}
                  <CardContent className="p-4">
                    <div className="space-y-2">
                      {item.title && (
                        <h3 className="font-heading text-base font-semibold text-darktext line-clamp-1">
                          {item.title}
                        </h3>
                      )}
                      <div className="flex items-center justify-between text-xs text-darktext/70">
                        {item.eventDate && (
                          <div className="flex items-center space-x-1">
                            <Calendar className="h-3 w-3" />
                            <span className="font-paragraph">{formatDate(item.eventDate)}</span>
                          </div>
                        )}
                        {item.location && (
                          <div className="flex items-center space-x-1">
                            <MapPin className="h-3 w-3" />
                            <span className="font-paragraph line-clamp-1">{item.location}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </section>

      {/* Activity Types Overview */}
      {activityTypes.length > 1 && (
        <section className="bg-secondary py-20">
          <div className="max-w-[120rem] mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="font-heading text-4xl font-bold text-darktext mb-4">Our Activities</h2>
              <p className="font-paragraph text-lg text-darktext/70 max-w-2xl mx-auto">
                We organize various activities to create a vibrant learning environment and build strong community bonds
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {activityTypes.slice(1).map((type, index) => {
                const typeCount = galleryItems.filter(item => item.activityType === type.value).length;
                return (
                  <motion.div
                    key={type.value}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                  >
                    <Card 
                      className="text-center bg-white border-0 hover:shadow-lg transition-all duration-300 cursor-pointer"
                      onClick={() => setSelectedType(type.value)}
                    >
                      <CardContent className="p-6">
                        <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                          <Camera className="h-6 w-6 text-primary-foreground" />
                        </div>
                        <h3 className="font-heading text-lg font-bold text-darktext mb-2">
                          {type.label}
                        </h3>
                        <p className="font-paragraph text-darktext/70 text-sm">
                          {typeCount} {typeCount === 1 ? 'photo' : 'photos'}
                        </p>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* Call to Action */}
      <section className="bg-gradient-to-r from-primary to-primary/80 py-20">
        <div className="max-w-[120rem] mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <h2 className="font-heading text-4xl lg:text-5xl font-bold text-darktext">
              Be Part of Our Story
            </h2>
            <p className="font-paragraph text-xl text-darktext/80 max-w-3xl mx-auto">
              Join our vibrant community and create your own success story with us
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-darktext text-white hover:bg-darktext/90">
                <Link to="/contact">Join Us Today</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="border-buttonborder text-darktext hover:bg-white/10">
                <Link to="/courses">View Courses</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-darktext text-white py-16">
        <div className="max-w-[120rem] mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-primary-foreground font-heading font-bold">TI</span>
                </div>
                <span className="font-heading text-lg font-bold">Training Institute</span>
              </div>
              <p className="font-paragraph text-white/70">
                Empowering careers through quality education and industry-relevant training programs.
              </p>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4">Quick Links</h3>
              <div className="space-y-2">
                <Link to="/about" className="block font-paragraph text-white/70 hover:text-white transition-colors">About Us</Link>
                <Link to="/courses" className="block font-paragraph text-white/70 hover:text-white transition-colors">Courses</Link>
                <Link to="/placement" className="block font-paragraph text-white/70 hover:text-white transition-colors">Placements</Link>
                <Link to="/contact" className="block font-paragraph text-white/70 hover:text-white transition-colors">Contact</Link>
              </div>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4">Courses</h3>
              <div className="space-y-2">
                <Link to="/courses/python" className="block font-paragraph text-white/70 hover:text-white transition-colors">Python Training</Link>
                <Link to="/courses/web-development" className="block font-paragraph text-white/70 hover:text-white transition-colors">Web Development</Link>
                <Link to="/courses/data-science" className="block font-paragraph text-white/70 hover:text-white transition-colors">Data Science</Link>
                <Link to="/courses/digital-marketing" className="block font-paragraph text-white/70 hover:text-white transition-colors">Digital Marketing</Link>
              </div>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4">Contact Info</h3>
              <div className="space-y-2 font-paragraph text-white/70">
                <p>123 Training Street</p>
                <p>Tech City, TC 12345</p>
                <p>Phone: +1 (555) 123-4567</p>
                <p>Email: info@traininginstitute.com</p>
              </div>
            </div>
          </div>
          <div className="border-t border-white/20 mt-12 pt-8 text-center">
            <p className="font-paragraph text-white/70">
              © 2024 Training Institute. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}