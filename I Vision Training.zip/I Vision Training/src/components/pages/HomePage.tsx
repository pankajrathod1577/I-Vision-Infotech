import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Image } from '@/components/ui/image';
import { InteractiveStats } from '@/components/ui/interactive-stats';
import { FloatingActionButton } from '@/components/ui/floating-action-button';
import { ArrowRight, Users, Award, BookOpen, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';

export default function HomePage() {
  const highlights = [
    {
      icon: <Users className="h-8 w-8 text-primary-foreground" />,
      title: "500+ Students Trained",
      description: "Successfully trained over 500 students in various technical skills"
    },
    {
      icon: <Award className="h-8 w-8 text-primary-foreground" />,
      title: "95% Placement Rate",
      description: "Excellent placement record with top companies in the industry"
    },
    {
      icon: <BookOpen className="h-8 w-8 text-primary-foreground" />,
      title: "Expert Faculty",
      description: "Industry experienced trainers with hands-on expertise"
    },
    {
      icon: <TrendingUp className="h-8 w-8 text-primary-foreground" />,
      title: "Latest Curriculum",
      description: "Updated course content aligned with industry requirements"
    }
  ];

  const featuredCourses = [
    {
      title: "Python Training",
      description: "Comprehensive Python programming course with real-world projects",
      duration: "3 months",
      image: "https://static.wixstatic.com/media/04ae4d_f2b9c982aa5d43fb93082d49ba9a1f5a~mv2.png?originWidth=384&originHeight=192"
    },
    {
      title: "Web Development",
      description: "Full-stack web development using modern technologies",
      duration: "4 months", 
      image: "https://static.wixstatic.com/media/04ae4d_8f3af525b6d04aad9ea623d0f9a2bbaa~mv2.png?originWidth=384&originHeight=192"
    },
    {
      title: "Data Science",
      description: "Master data analysis, machine learning, and AI concepts",
      duration: "6 months",
      image: "https://static.wixstatic.com/media/04ae4d_a92dc07677964e0ebb994dbb716a7d19~mv2.png?originWidth=384&originHeight=192"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <FloatingActionButton />
      
      {/* Navigation */}
      <nav className="bg-white/95 backdrop-blur-md shadow-lg border-b border-blue-100 sticky top-0 z-50">
        <div className="max-w-[120rem] mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-blue-500 rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white font-heading font-bold text-lg">IV</span>
              </div>
              <span className="font-heading text-2xl font-bold bg-gradient-to-r from-darktext to-blue-600 bg-clip-text text-transparent">I vision Training</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <Link to="/" className="text-darktext hover:text-blue-600 transition-all duration-300 font-paragraph relative group">
                Home
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link to="/about" className="text-darktext hover:text-blue-600 transition-all duration-300 font-paragraph relative group">
                About
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link to="/courses" className="text-darktext hover:text-blue-600 transition-all duration-300 font-paragraph relative group">
                Courses
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link to="/gallery" className="text-darktext hover:text-blue-600 transition-all duration-300 font-paragraph relative group">
                Gallery
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link to="/placement" className="text-darktext hover:text-blue-600 transition-all duration-300 font-paragraph relative group">
                Placement
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link to="/contact" className="text-darktext hover:text-blue-600 transition-all duration-300 font-paragraph relative group">
                Contact
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-blue-600 group-hover:w-full transition-all duration-300"></span>
              </Link>
            </div>
            <Button asChild className="bg-gradient-to-r from-blue-500 to-blue-600 text-white hover:from-blue-600 hover:to-blue-700 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <Link to="/contact">Get Started</Link>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative w-full max-w-[120rem] mx-auto px-6 py-24 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-indigo-400/20 to-blue-400/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>
        
        <div className="relative grid lg:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <Badge className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-4 py-2 text-sm font-semibold shadow-lg">
                  🚀 Leading Training Institute
                </Badge>
              </motion.div>
              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="font-heading text-5xl lg:text-7xl font-bold text-darktext leading-tight"
              >
                Transform Your Career with 
                <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent"> Expert Training</span>
              </motion.h1>
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="font-paragraph text-xl text-darktext/80 max-w-xl leading-relaxed"
              >
                Join thousands of successful professionals who have advanced their careers through our comprehensive training programs. Learn from industry experts and get placed in top companies.
              </motion.p>
            </div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Button asChild size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
                <Link to="/courses">
                  Explore Courses <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="border-2 border-blue-300 text-blue-700 hover:bg-blue-50 hover:border-blue-400 transition-all duration-300 transform hover:scale-105">
                <Link to="/placement">View Success Stories</Link>
              </Button>
            </motion.div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative bg-white rounded-3xl p-8 shadow-2xl border border-blue-100">
              <div className="absolute -top-4 -right-4 w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full"></div>
              <div className="absolute -bottom-4 -left-4 w-6 h-6 bg-gradient-to-br from-indigo-500 to-blue-500 rounded-full"></div>
              
              <Image 
                src="https://static.wixstatic.com/media/04ae4d_033475b329524f42ba0b2ee839728296~mv2.png?originWidth=576&originHeight=320"
                alt="Students learning in modern classroom"
                width={600}
                className="w-full h-80 object-cover rounded-2xl"
              />
              
              <div className="mt-8 grid grid-cols-2 gap-6">
                <motion.div 
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.6, delay: 0.8 }}
                  className="text-center p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl"
                >
                  <div className="font-heading text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">500+</div>
                  <div className="font-paragraph text-sm text-darktext/70">Students Trained</div>
                </motion.div>
                <motion.div 
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.6, delay: 0.9 }}
                  className="text-center p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl"
                >
                  <div className="font-heading text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">95%</div>
                  <div className="font-paragraph text-sm text-darktext/70">Placement Rate</div>
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Interactive Stats Section */}
      <section className="max-w-[120rem] mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="font-heading text-3xl font-bold bg-gradient-to-r from-darktext to-blue-600 bg-clip-text text-transparent mb-4"
          >
            Our Impact in Numbers
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-paragraph text-lg text-darktext/70 max-w-2xl mx-auto"
          >
            See how we've transformed careers and built success stories
          </motion.p>
        </div>
        <InteractiveStats />
      </section>

      {/* Highlights Section */}
      <section className="max-w-[120rem] mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="font-heading text-4xl font-bold bg-gradient-to-r from-darktext to-blue-600 bg-clip-text text-transparent mb-4"
          >
            Why Choose I vision Training
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-paragraph text-lg text-darktext/70 max-w-2xl mx-auto"
          >
            We provide comprehensive training with industry-relevant curriculum and excellent placement support
          </motion.p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {highlights.map((highlight, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -10, scale: 1.02 }}
              className="group"
            >
              <Card className="text-center h-full bg-gradient-to-br from-white to-blue-50/50 border-0 hover:shadow-2xl transition-all duration-500 group-hover:border-blue-200">
                <CardHeader>
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                    <div className="text-white">
                      {highlight.icon}
                    </div>
                  </div>
                  <CardTitle className="font-heading text-xl text-darktext group-hover:text-blue-600 transition-colors duration-300">{highlight.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="font-paragraph text-darktext/70">
                    {highlight.description}
                  </CardDescription>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Featured Courses Section */}
      <section className="bg-gradient-to-br from-gray-50 to-blue-50/30 py-20">
        <div className="max-w-[120rem] mx-auto px-6">
          <div className="text-center mb-16">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="font-heading text-4xl font-bold bg-gradient-to-r from-darktext to-blue-600 bg-clip-text text-transparent mb-4"
            >
              Featured Courses
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="font-paragraph text-lg text-darktext/70 max-w-2xl mx-auto"
            >
              Explore our most popular training programs designed to boost your career
            </motion.p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredCourses.map((course, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -10, scale: 1.02 }}
                className="group"
              >
                <Card className="overflow-hidden hover:shadow-2xl transition-all duration-500 bg-white border-0 group-hover:border-blue-200">
                  <div className="relative overflow-hidden">
                    <Image 
                      src={course.image}
                      alt={course.title}
                      width={400}
                      className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <Badge className="absolute top-4 right-4 bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg">
                      {course.duration}
                    </Badge>
                  </div>
                  <CardHeader>
                    <CardTitle className="font-heading text-xl text-darktext group-hover:text-blue-600 transition-colors duration-300">{course.title}</CardTitle>
                    <CardDescription className="font-paragraph text-darktext/70">
                      {course.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button asChild className="w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white hover:from-blue-600 hover:to-purple-600 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
                      <Link to="/courses">Learn More</Link>
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="relative bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-700 py-20 overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-1/4 w-64 h-64 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-0 right-1/4 w-48 h-48 bg-white/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>
        
        <div className="relative max-w-[120rem] mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="font-heading text-4xl lg:text-6xl font-bold text-white"
            >
              Ready to Start Your Journey?
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="font-paragraph text-xl text-white/90 max-w-3xl mx-auto leading-relaxed"
            >
              Join our next batch and transform your career with industry-relevant skills and guaranteed placement support
            </motion.p>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-gray-100 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 font-semibold">
                <Link to="/contact">
                  Enroll Now <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="border-2 border-white text-white hover:bg-white/10 hover:border-white transition-all duration-300 transform hover:scale-105">
                <Link to="/courses">Browse Courses</Link>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-gray-900 to-blue-900 text-white py-16">
        <div className="max-w-[120rem] mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center shadow-lg">
                  <span className="text-white font-heading font-bold">IV</span>
                </div>
                <span className="font-heading text-xl font-bold bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">I vision Training</span>
              </div>
              <p className="font-paragraph text-white/70 leading-relaxed">
                Empowering careers through quality education and industry-relevant training programs.
              </p>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4 text-blue-200">Quick Links</h3>
              <div className="space-y-2">
                <Link to="/about" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">About Us</Link>
                <Link to="/courses" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Courses</Link>
                <Link to="/placement" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Placements</Link>
                <Link to="/contact" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Contact</Link>
              </div>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4 text-blue-200">Courses</h3>
              <div className="space-y-2">
                <Link to="/courses/python" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Python Training</Link>
                <Link to="/courses/web-development" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Web Development</Link>
                <Link to="/courses/data-science" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Data Science</Link>
                <Link to="/courses/digital-marketing" className="block font-paragraph text-white/70 hover:text-blue-200 transition-colors duration-300">Digital Marketing</Link>
              </div>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4 text-blue-200">Contact Info</h3>
              <div className="space-y-2 font-paragraph text-white/70">
                <p>123 Training Street</p>
                <p>Tech City, TC 12345</p>
                <p>Phone: +1 (555) 123-4567</p>
                <p>Email: info@ivisiontraining.com</p>
              </div>
            </div>
          </div>
          <div className="border-t border-white/20 mt-12 pt-8 text-center">
            <p className="font-paragraph text-white/70">
              © 2024 I vision Training. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}