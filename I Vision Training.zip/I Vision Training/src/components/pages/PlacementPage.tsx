import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Image } from '@/components/ui/image';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Building, User, Quote, Filter, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import { BaseCrudService } from '@/integrations';
import { PlacedStudents } from '@/entities';
import { format } from 'date-fns';

export default function PlacementPage() {
  const [placedStudents, setPlacedStudents] = useState<PlacedStudents[]>([]);
  const [filteredStudents, setFilteredStudents] = useState<PlacedStudents[]>([]);
  const [selectedCompany, setSelectedCompany] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPlacedStudents = async () => {
      try {
        const { items } = await BaseCrudService.getAll<PlacedStudents>('placedstudents');
        setPlacedStudents(items);
        setFilteredStudents(items);
      } catch (error) {
        console.error('Error fetching placed students:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPlacedStudents();
  }, []);

  // Get unique companies for filter
  const companies = [
    { value: 'all', label: 'All Companies' },
    ...Array.from(new Set(placedStudents.map(student => student.companyPlacedAt).filter(Boolean)))
      .map(company => ({ value: company!, label: company! }))
  ];

  useEffect(() => {
    if (selectedCompany === 'all') {
      setFilteredStudents(placedStudents);
    } else {
      setFilteredStudents(placedStudents.filter(student => student.companyPlacedAt === selectedCompany));
    }
  }, [selectedCompany, placedStudents]);

  const handleCompanyChange = (value: string) => {
    setSelectedCompany(value);
  };

  const formatDate = (date: Date | string | undefined) => {
    if (!date) return 'Date not specified';
    try {
      const dateObj = typeof date === 'string' ? new Date(date) : date;
      return format(dateObj, 'MMM yyyy');
    } catch {
      return 'Date not specified';
    }
  };

  // Calculate placement statistics
  const placementStats = {
    totalPlacements: placedStudents.length,
    uniqueCompanies: companies.length - 1, // Exclude 'all' option
    placementRate: 95, // This could be calculated based on total students vs placed students
    averageSalary: '₹6.5 LPA' // This could be calculated if salary data is available
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="font-paragraph text-darktext/70">Loading placements...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-[120rem] mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-heading font-bold text-lg">TI</span>
              </div>
              <span className="font-heading text-xl font-bold text-darktext">Training Institute</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <Link to="/" className="text-darktext hover:text-primary transition-colors font-paragraph">Home</Link>
              <Link to="/about" className="text-darktext hover:text-primary transition-colors font-paragraph">About</Link>
              <Link to="/courses" className="text-darktext hover:text-primary transition-colors font-paragraph">Courses</Link>
              <Link to="/gallery" className="text-darktext hover:text-primary transition-colors font-paragraph">Gallery</Link>
              <Link to="/placement" className="text-primary font-paragraph font-semibold">Placement</Link>
              <Link to="/contact" className="text-darktext hover:text-primary transition-colors font-paragraph">Contact</Link>
            </div>
            <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Link to="/contact">Get Started</Link>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary via-primary/80 to-secondary py-20">
        <div className="max-w-[120rem] mx-auto px-6">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center space-y-6"
          >
            <h1 className="font-heading text-5xl lg:text-6xl font-bold text-darktext">
              Student Placements
            </h1>
            <p className="font-paragraph text-xl text-darktext/80 max-w-3xl mx-auto">
              Celebrating the success stories of our graduates who have secured excellent positions in top companies
            </p>
          </motion.div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="max-w-[120rem] mx-auto px-6 py-16">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            {
              icon: <User className="h-8 w-8 text-primary-foreground" />,
              number: placementStats.totalPlacements.toString(),
              label: "Students Placed"
            },
            {
              icon: <Building className="h-8 w-8 text-primary-foreground" />,
              number: placementStats.uniqueCompanies.toString() + "+",
              label: "Partner Companies"
            },
            {
              icon: <TrendingUp className="h-8 w-8 text-primary-foreground" />,
              number: placementStats.placementRate + "%",
              label: "Placement Rate"
            },
            {
              icon: <Calendar className="h-8 w-8 text-primary-foreground" />,
              number: placementStats.averageSalary,
              label: "Average Package"
            }
          ].map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="text-center"
            >
              <Card className="bg-secondary border-0 hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    {stat.icon}
                  </div>
                  <div className="font-heading text-3xl font-bold text-darktext mb-2">
                    {stat.number}
                  </div>
                  <div className="font-paragraph text-darktext/70">
                    {stat.label}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Filter Section */}
      <section className="max-w-[120rem] mx-auto px-6 py-12">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-2">
            <h2 className="font-heading text-2xl font-bold text-darktext">
              Our Success Stories ({filteredStudents.length})
            </h2>
            <p className="font-paragraph text-darktext/70">
              Meet our graduates who are now thriving in their careers
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <Filter className="h-5 w-5 text-darktext/70" />
            <Select value={selectedCompany} onValueChange={handleCompanyChange}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by company" />
              </SelectTrigger>
              <SelectContent>
                {companies.map((company) => (
                  <SelectItem key={company.value} value={company.value}>
                    {company.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </section>

      {/* Placed Students Grid */}
      <section className="max-w-[120rem] mx-auto px-6 pb-20">
        {filteredStudents.length === 0 ? (
          <div className="text-center py-16">
            <User className="h-16 w-16 text-darktext/30 mx-auto mb-4" />
            <h3 className="font-heading text-xl font-bold text-darktext mb-2">No placements found</h3>
            <p className="font-paragraph text-darktext/70">
              Try selecting a different company or check back later for new placements.
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredStudents.map((student, index) => (
              <motion.div
                key={student._id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 bg-white border-0 h-full">
                  <CardHeader className="text-center pb-4">
                    <div className="w-20 h-20 mx-auto mb-4 overflow-hidden rounded-full">
                      <Image 
                        src={student.studentPhoto || "https://static.wixstatic.com/media/04ae4d_dcfe1f6b3f0e45cea3b5843b1611073b~mv2.png?originWidth=128&originHeight=128"}
                        alt={student.studentName || "Student photo"}
                        width={80}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <CardTitle className="font-heading text-xl text-darktext">
                      {student.studentName}
                    </CardTitle>
                    <CardDescription className="font-paragraph text-primary font-semibold">
                      {student.jobTitle}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-center">
                      <Badge className="bg-primary text-primary-foreground">
                        {student.companyPlacedAt}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center justify-center text-sm text-darktext/70">
                      <Calendar className="h-4 w-4 mr-2" />
                      <span className="font-paragraph">Placed in {formatDate(student.placementDate)}</span>
                    </div>

                    {student.testimonial && (
                      <div className="bg-contentblockbackground p-4 rounded-lg">
                        <Quote className="h-4 w-4 text-primary mb-2" />
                        <p className="font-paragraph text-sm text-darktext/80 italic line-clamp-4">
                          "{student.testimonial}"
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </section>

      {/* Company Partners Section */}
      {companies.length > 1 && (
        <section className="bg-secondary py-20">
          <div className="max-w-[120rem] mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="font-heading text-4xl font-bold text-darktext mb-4">Our Placement Partners</h2>
              <p className="font-paragraph text-lg text-darktext/70 max-w-2xl mx-auto">
                We have strong partnerships with leading companies across various industries
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {companies.slice(1).map((company, index) => {
                const companyPlacements = placedStudents.filter(student => student.companyPlacedAt === company.value).length;
                return (
                  <motion.div
                    key={company.value}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                  >
                    <Card 
                      className="text-center bg-white border-0 hover:shadow-lg transition-all duration-300 cursor-pointer"
                      onClick={() => setSelectedCompany(company.value)}
                    >
                      <CardContent className="p-6">
                        <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                          <Building className="h-6 w-6 text-primary-foreground" />
                        </div>
                        <h3 className="font-heading text-lg font-bold text-darktext mb-2">
                          {company.label}
                        </h3>
                        <p className="font-paragraph text-darktext/70 text-sm">
                          {companyPlacements} {companyPlacements === 1 ? 'placement' : 'placements'}
                        </p>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* Placement Process Section */}
      <section className="max-w-[120rem] mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <h2 className="font-heading text-4xl font-bold text-darktext mb-4">Our Placement Process</h2>
          <p className="font-paragraph text-lg text-darktext/70 max-w-2xl mx-auto">
            We provide comprehensive placement support to ensure our students succeed in their career goals
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            {
              step: "01",
              title: "Skill Assessment",
              description: "Evaluate student skills and identify areas for improvement"
            },
            {
              step: "02", 
              title: "Resume Building",
              description: "Create professional resumes that highlight strengths and achievements"
            },
            {
              step: "03",
              title: "Interview Preparation",
              description: "Conduct mock interviews and provide feedback for improvement"
            },
            {
              step: "04",
              title: "Job Placement",
              description: "Connect students with suitable job opportunities in partner companies"
            }
          ].map((process, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="text-center bg-white border-0 hover:shadow-lg transition-shadow h-full">
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="font-heading text-xl font-bold text-primary-foreground">
                      {process.step}
                    </span>
                  </div>
                  <h3 className="font-heading text-lg font-bold text-darktext mb-3">
                    {process.title}
                  </h3>
                  <p className="font-paragraph text-darktext/70 text-sm">
                    {process.description}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-gradient-to-r from-primary to-primary/80 py-20">
        <div className="max-w-[120rem] mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <h2 className="font-heading text-4xl lg:text-5xl font-bold text-darktext">
              Ready to Start Your Success Story?
            </h2>
            <p className="font-paragraph text-xl text-darktext/80 max-w-3xl mx-auto">
              Join our successful graduates and take the next step towards your dream career
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-darktext text-white hover:bg-darktext/90">
                <Link to="/contact">Apply Now</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="border-buttonborder text-darktext hover:bg-white/10">
                <Link to="/courses">View Courses</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-darktext text-white py-16">
        <div className="max-w-[120rem] mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-primary-foreground font-heading font-bold">TI</span>
                </div>
                <span className="font-heading text-lg font-bold">Training Institute</span>
              </div>
              <p className="font-paragraph text-white/70">
                Empowering careers through quality education and industry-relevant training programs.
              </p>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4">Quick Links</h3>
              <div className="space-y-2">
                <Link to="/about" className="block font-paragraph text-white/70 hover:text-white transition-colors">About Us</Link>
                <Link to="/courses" className="block font-paragraph text-white/70 hover:text-white transition-colors">Courses</Link>
                <Link to="/placement" className="block font-paragraph text-white/70 hover:text-white transition-colors">Placements</Link>
                <Link to="/contact" className="block font-paragraph text-white/70 hover:text-white transition-colors">Contact</Link>
              </div>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4">Courses</h3>
              <div className="space-y-2">
                <Link to="/courses/python" className="block font-paragraph text-white/70 hover:text-white transition-colors">Python Training</Link>
                <Link to="/courses/web-development" className="block font-paragraph text-white/70 hover:text-white transition-colors">Web Development</Link>
                <Link to="/courses/data-science" className="block font-paragraph text-white/70 hover:text-white transition-colors">Data Science</Link>
                <Link to="/courses/digital-marketing" className="block font-paragraph text-white/70 hover:text-white transition-colors">Digital Marketing</Link>
              </div>
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold mb-4">Contact Info</h3>
              <div className="space-y-2 font-paragraph text-white/70">
                <p>123 Training Street</p>
                <p>Tech City, TC 12345</p>
                <p>Phone: +1 (555) 123-4567</p>
                <p>Email: info@traininginstitute.com</p>
              </div>
            </div>
          </div>
          <div className="border-t border-white/20 mt-12 pt-8 text-center">
            <p className="font-paragraph text-white/70">
              © 2024 Training Institute. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}