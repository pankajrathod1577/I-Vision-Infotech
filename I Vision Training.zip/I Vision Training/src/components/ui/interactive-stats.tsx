import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Users, Award, BookOpen, TrendingUp } from 'lucide-react';

interface StatItem {
  icon: React.ReactNode;
  value: number;
  label: string;
  suffix?: string;
  color: string;
}

export function InteractiveStats() {
  const [animatedValues, setAnimatedValues] = useState<number[]>([0, 0, 0, 0]);
  const [isVisible, setIsVisible] = useState(false);

  const stats: StatItem[] = [
    {
      icon: <Users className="h-8 w-8" />,
      value: 500,
      label: "Students Trained",
      suffix: "+",
      color: "from-blue-500 to-purple-500"
    },
    {
      icon: <Award className="h-8 w-8" />,
      value: 95,
      label: "Placement Rate",
      suffix: "%",
      color: "from-purple-500 to-pink-500"
    },
    {
      icon: <BookOpen className="h-8 w-8" />,
      value: 50,
      label: "Partner Companies",
      suffix: "+",
      color: "from-indigo-500 to-blue-500"
    },
    {
      icon: <TrendingUp className="h-8 w-8" />,
      value: 10,
      label: "Years Experience",
      suffix: "+",
      color: "from-blue-500 to-indigo-500"
    }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById('interactive-stats');
    if (element) {
      observer.observe(element);
    }

    return () => {
      if (element) {
        observer.unobserve(element);
      }
    };
  }, []);

  useEffect(() => {
    if (isVisible) {
      stats.forEach((stat, index) => {
        let start = 0;
        const end = stat.value;
        const duration = 2000; // 2 seconds
        const increment = end / (duration / 16); // 60fps

        const timer = setInterval(() => {
          start += increment;
          if (start >= end) {
            start = end;
            clearInterval(timer);
          }
          
          setAnimatedValues(prev => {
            const newValues = [...prev];
            newValues[index] = Math.floor(start);
            return newValues;
          });
        }, 16);

        return () => clearInterval(timer);
      });
    }
  }, [isVisible]);

  return (
    <div id="interactive-stats" className="grid grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 30, scale: 0.8 }}
          animate={isVisible ? { opacity: 1, y: 0, scale: 1 } : {}}
          transition={{ duration: 0.6, delay: index * 0.1 }}
          whileHover={{ y: -10, scale: 1.05 }}
          className="group cursor-pointer"
        >
          <Card className="bg-gradient-to-br from-white to-blue-50/50 border-0 hover:shadow-2xl transition-all duration-500 group-hover:border-blue-200 overflow-hidden relative">
            {/* Animated background gradient */}
            <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}></div>
            
            <CardContent className="p-6 text-center relative z-10">
              <div className={`w-16 h-16 bg-gradient-to-br ${stat.color} rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                <div className="text-white">
                  {stat.icon}
                </div>
              </div>
              
              <motion.div 
                className="font-heading text-3xl lg:text-4xl font-bold bg-gradient-to-r from-darktext to-blue-600 bg-clip-text text-transparent mb-2"
                key={animatedValues[index]}
                initial={{ scale: 1.2, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                {animatedValues[index]}{stat.suffix}
              </motion.div>
              
              <div className="font-paragraph text-sm text-darktext/70 group-hover:text-darktext transition-colors duration-300">
                {stat.label}
              </div>
              
              {/* Animated progress bar */}
              <div className="mt-3 h-1 bg-gray-200 rounded-full overflow-hidden">
                <motion.div
                  className={`h-full bg-gradient-to-r ${stat.color} rounded-full`}
                  initial={{ width: 0 }}
                  animate={isVisible ? { width: '100%' } : { width: 0 }}
                  transition={{ duration: 2, delay: index * 0.2 }}
                />
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}