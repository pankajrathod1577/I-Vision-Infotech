/**
 * Auto-generated entity types
 * Contains all CMS collection interfaces in a single file 
 */

/**
 * Collection ID: courses
 * Interface for Courses
 */
export interface Courses {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  courseName?: string;
  /** @wixFieldType text */
  courseDescription?: string;
  /** @wixFieldType text */
  courseType?: string;
  /** @wixFieldType image */
  courseThumbnail?: string;
  /** @wixFieldType text */
  courseDuration?: string;
  /** @wixFieldType text */
  learningOutcomes?: string;
  /** @wixFieldType number */
  coursePrice?: number;
}


/**
 * Collection ID: galleryitems
 * Interface for GalleryItems
 */
export interface GalleryItems {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  title?: string;
  /** @wixFieldType text */
  activityType?: string;
  /** @wixFieldType image */
  photo?: string;
  /** @wixFieldType text */
  description?: string;
  /** @wixFieldType date */
  eventDate?: Date | string;
  /** @wixFieldType text */
  location?: string;
}


/**
 * Collection ID: placedstudents
 * Interface for PlacedStudents
 */
export interface PlacedStudents {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  studentName?: string;
  /** @wixFieldType image */
  studentPhoto?: string;
  /** @wixFieldType text */
  companyPlacedAt?: string;
  /** @wixFieldType text */
  jobTitle?: string;
  /** @wixFieldType date */
  placementDate?: Date | string;
  /** @wixFieldType text */
  testimonial?: string;
}
